﻿using System.Net;
using System.Net.Sockets;
using UPDBroadcast;

/*var i = Console.ReadLine();

foreach (var e in i.Split(':'))
{
    Console.WriteLine($"[{e}]");
}*/


ChatUDP chat = new ChatUDP(5000);
try
{
    chat.Bind();
}
catch (Exception e)
{
    Console.WriteLine("Error while Bind receiver socket");
    Console.WriteLine(e);
    return;
}

chat.SendConnectStatus();

chat.Listen();
chat.Send();

/*String strHostName = string.Empty;
// Getting Ip address of local machine...
// First get the host name of local machine.
strHostName = Dns.GetHostName();
Console.WriteLine("Local Machine's Host Name: " + strHostName);
// Then using host name, get the IP address list..
IPHostEntry ipEntry = Dns.GetHostEntry(strHostName);
IPAddress[] addr = ipEntry.AddressList;


for (int i = 0; i < addr.Length; i++)
{
    if(addr[i].AddressFamily == AddressFamily.InterNetwork)
        Console.WriteLine("IP Address {0}: {1} ", i, addr[i]);
    
}
Console.ReadLine();*/