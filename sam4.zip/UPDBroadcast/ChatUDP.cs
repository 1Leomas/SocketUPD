﻿using System.Net;
using System.Net.Sockets;
using System.Text;

namespace UPDBroadcast;

internal class ChatUDP
{
    private readonly Socket _sender;
    private readonly Socket _receiver;
    private int _port { get; }

    public ChatUDP(int port)
    {
        _sender = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        _sender.EnableBroadcast = true;

        _receiver = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

        _port = port;
    }

    public void Bind()
    {
        var localIP = new IPEndPoint(IPAddress.Any, _port);
        //need Bind to receive data
        _receiver.Bind(localIP);

        Console.WriteLine("Listening on {0}", localIP);
    }

    public void SendConnectStatus()
    {
        var byteToSend = Encoding.UTF8.GetBytes("name connected to server");
        EndPoint remotePoint = new IPEndPoint(IPAddress.Broadcast, _port);
        _sender.SendTo(byteToSend, remotePoint);
    }

    public void Send()
    {
        Console.WriteLine("Input message and press ENTER");
        while (true)
        {
            var message = Console.ReadLine() ?? "";
            var byteToSend = Encoding.UTF8.GetBytes(message);

            EndPoint remotePoint = new IPEndPoint(IPAddress.Broadcast, _port);

            _sender.SendTo(byteToSend, remotePoint);
        }
    }

    public void Listen()
    {
        Task.Run(() =>
        {
            while (true)
            {
                byte[] byteReceive = new byte[1024];
                EndPoint remoteIp = new IPEndPoint(IPAddress.Any, 0);

                _receiver.ReceiveFrom(byteReceive, ref remoteIp);

                var message = Encoding.UTF8.GetString(byteReceive);

                Console.WriteLine("Received from {0} : {1}", remoteIp, message);
            }
        });
    }
}